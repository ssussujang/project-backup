package com.example.practice.ai;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.example.practice.dto.receipt.ReceiptDTO;
import com.example.practice.mapper.ReceiptMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ReceiptAiService {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final ReceiptMapper receiptMapper;
    private final String apiKey;

    public ReceiptAiService(RestTemplate restTemplate,
                            ObjectMapper objectMapper,
                            ReceiptMapper receiptMapper,
                            @Value("${openai.api-key}") String apiKey) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
        this.receiptMapper = receiptMapper;
        this.apiKey = apiKey;
    }

    /**
     * 이미지 + 로그인한 유저ID 받아서
     * 1) OpenAI로 영수증 분석
     * 2) 결과 JSON 반환
     * 3) total 금액을 receipt_tb에 저장
     */
    public String analyzeReceipt(MultipartFile image, String uId) throws IOException {

        // 1) 이미지 -> dataURL(Base64)
        String base64 = Base64.getEncoder().encodeToString(image.getBytes());
        String mimeType = image.getContentType();
        if (mimeType == null) {
            mimeType = "image/png";
        }
        String dataUrl = "data:" + mimeType + ";base64," + base64;

        // 2) Chat Completions용 메시지 구성
        Map<String, Object> systemMsg = new HashMap<>();
        systemMsg.put("role", "system");
        systemMsg.put("content",
                "너는 영수증을 분석해서 항목별로 카테고리를 분류해 주는 어시스턴트야. " +
                        "항상 JSON 형식만 반환해. 예시는 다음과 같아:\n" +
                        "{\n" +
                        "  \"items\": [\n" +
                        "    {\"name\": \"아메리카노\", \"price\": 4500, \"category\": \"카페\"},\n" +
                        "    {\"name\": \"버스\", \"price\": 1400, \"category\": \"교통\"}\n" +
                        "  ],\n" +
                        "  \"categorySummary\": {\n" +
                        "    \"카페\": 4500,\n" +
                        "    \"교통\": 1400\n" +
                        "  },\n" +
                        "  \"total\": 5900\n" +
                        "}");

        Map<String, Object> textPart = new HashMap<>();
        textPart.put("type", "text");
        textPart.put("text", "이 영수증을 보고 항목별 카테고리와 금액을 위 JSON 형태로만 출력해 줘.");

        Map<String, Object> imageUrl = new HashMap<>();
        imageUrl.put("url", dataUrl);

        Map<String, Object> imagePart = new HashMap<>();
        imagePart.put("type", "image_url");
        imagePart.put("image_url", imageUrl);

        List<Object> userContent = List.of(textPart, imagePart);

        Map<String, Object> userMsg = new HashMap<>();
        userMsg.put("role", "user");
        userMsg.put("content", userContent);

        Map<String, Object> body = new HashMap<>();
        body.put("model", "gpt-4.1-mini");
        body.put("messages", List.of(systemMsg, userMsg));
        body.put("temperature", 0);

        // 3) HTTP 요청
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        @SuppressWarnings("unchecked")
        Map<String, Object> response = restTemplate.postForObject(
                "https://api.openai.com/v1/chat/completions",
                entity,
                Map.class
        );

        if (response == null) {
            return "OpenAI 응답이 없습니다.";
        }

        // 4) choices[0].message.content 추출
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> choices =
                (List<Map<String, Object>>) response.get("choices");

        if (choices == null || choices.isEmpty()) {
            return "choices 가 비어 있습니다: " + response;
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> message =
                (Map<String, Object>) choices.get(0).get("message");

        Object contentObj = message.get("content");

        String rawText;   // OpenAI가 준 내용(백틱 포함 가능)

        if (contentObj instanceof String) {
            rawText = (String) contentObj;
        } else if (contentObj instanceof List) {
            StringBuilder sb = new StringBuilder();
            for (Object partObj : (List<?>) contentObj) {
                if (partObj instanceof Map) {
                    Map<?, ?> partMap = (Map<?, ?>) partObj;
                    if ("text".equals(partMap.get("type"))) {
                        Object txt = partMap.get("text");
                        if (txt != null) {
                            sb.append(txt.toString());
                        }
                    }
                }
            }
            rawText = sb.toString();
        } else {
            rawText = message.toString();
        }

        // 5) ```json ... ``` 이런 래핑 제거 (있으면)
        String cleaned = rawText.trim();
        if (cleaned.startsWith("```")) {
            int firstBrace = cleaned.indexOf('{');
            int lastBrace = cleaned.lastIndexOf('}');
            if (firstBrace != -1 && lastBrace != -1 && lastBrace >= firstBrace) {
                cleaned = cleaned.substring(firstBrace, lastBrace + 1);
            }
        }

        // 6) JSON 파싱해서 total 꺼내고 DB 저장
        try {
            JsonNode root = objectMapper.readTree(cleaned);

            int total = root.path("total").asInt(0);

            // 할인 정보 없으니 일단 이렇게 저장
            int before   = total;
            int discount = 0;

            ReceiptDTO dto = new ReceiptDTO();
            dto.setUid(uId);
            dto.setRBefore(before);
            dto.setRDiscount(discount);
            dto.setRTotal(total);

            receiptMapper.insertReceipt(dto);

        } catch (Exception e) {
            // DB 저장 실패해도 일단 화면에는 결과 보여주도록 로그만 찍기
            e.printStackTrace();
        }

        // 7) 화면에는 JSON 문자열 그대로 전달
        return cleaned;
    }
}

