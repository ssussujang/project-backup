package com.example.practice.controller.receipt;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.practice.dto.DTO;
import com.example.practice.dto.receipt.ReceiptStatsDTO;
import com.example.practice.service.receipt.ReceiptResultService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/ai")
@RequiredArgsConstructor
public class ReceiptResultController {

    private final ReceiptResultService receiptResultService;

    @GetMapping("/result")
    public String showMyReceiptResult(HttpSession session, Model model) {

        DTO loginUser = (DTO) session.getAttribute("loginUser");
        if (loginUser == null) {
            return "redirect:/welcome";
        }

        String uId = loginUser.getU_id();

        // ✅ 서비스에서 통계 한 번에 가져오기
        ReceiptStatsDTO stats = receiptResultService.getStats(uId);

        model.addAttribute("dailyData",  stats.getDailyData());
        model.addAttribute("weeklyData", stats.getWeeklyData());
        model.addAttribute("monthlyData", stats.getMonthlyData());
        model.addAttribute("genderData", stats.getGenderData());
        model.addAttribute("myAvg",      stats.getMyAvg());
        model.addAttribute("allAvg",     stats.getAllAvg());

        return "ai/result";
    }
}

