package com.example.practice.service.receipt;

import org.springframework.stereotype.Service;

import com.example.practice.dto.receipt.ReceiptDTO;
import com.example.practice.mapper.ReceiptMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReceiptSaveService {

    private final ObjectMapper objectMapper;
    private final ReceiptMapper receiptMapper;

    /**
     * OpenAI가 준 JSON 문자열(resultJson)을 파싱해서
     * receipt_tb 에 한 건 저장하는 메서드
     */
    public void saveFromAiResult(String uId, String resultJson) {
        try {
            JsonNode root = objectMapper.readTree(resultJson);

            // 1) item 가격 합 = r_before
            int rBefore = 0;
            JsonNode items = root.path("items");
            if (items.isArray()) {
                for (JsonNode item : items) {
                    rBefore += item.path("price").asInt(0);
                }
            }

            // 2) total (실제 결제 금액)
            int rTotal = root.path("total").asInt(rBefore);

            // 3) 할인 금액 = before - total (마이너스 방지)
            int rDiscount = rBefore - rTotal;
            if (rDiscount < 0) rDiscount = 0;

            // 4) DTO 만들어서 INSERT
            ReceiptDTO dto = new ReceiptDTO();
            dto.setUid(uId);
            dto.setRBefore(rBefore);
            dto.setRDiscount(rDiscount);
            dto.setRTotal(rTotal);

            receiptMapper.insertReceipt(dto);

            log.info("영수증 저장 완료. uId={}, before={}, discount={}, total={}",
                    uId, rBefore, rDiscount, rTotal);

        } catch (Exception e) {
            // 그래프 안 나오는 건 치명적이진 않으니까, 일단 로그만 찍고 화면은 그대로 진행
            log.error("영수증 저장 중 오류", e);
        }
    }
}
