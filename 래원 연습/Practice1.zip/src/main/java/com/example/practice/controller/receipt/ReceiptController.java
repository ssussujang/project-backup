package com.example.practice.controller.receipt;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.practice.ai.ReceiptAiService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/ai")
@RequiredArgsConstructor
public class ReceiptController {

	private final ReceiptAiService receiptAiService;
	
	 // 업로드 페이지
    @GetMapping("/receipt")
    public String showReceiptForm() {
        return "ai/receipt";
    }
    
    @PostMapping("/receipt")
    public String analyzeReceipt(@RequestParam("file") MultipartFile file,
    							Model model) {
    	if (file.isEmpty()) {
			model.addAttribute("error", "이미지 파일을 선택하세요.");
			return "ai/receipt";
		}
    	
    	try {
			String resultJson = receiptAiService.analyzeReceipt(file);
			model.addAttribute("resultJson", resultJson);
		} catch (Exception e) {
			 e.printStackTrace();
	         model.addAttribute("error",
	               "영수증 분석 중 오류가 발생했습니다: " + e.getMessage());
    }
        return "ai/receipt";
        }

}
