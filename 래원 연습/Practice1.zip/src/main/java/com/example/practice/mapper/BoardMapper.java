package com.example.practice.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import com.example.practice.dto.board.BoardDTO;
import com.example.practice.dto.search.SearchDto;

@Mapper
public interface BoardMapper {
    int insertBoard(BoardDTO dto);        
    BoardDTO selectBoardById(int b_id);
    List<BoardDTO> selectAllBoards(SearchDto searchDto);
    int updateBoard(BoardDTO dto);          
    int deleteBoard(int b_id);   
    int selectBoardCount();

}
