package com.example.practice.dto.receipt;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class ReceiptDTO {
	private String rid;
	private String uid;
	
	  private Integer rBefore;    
	  private Integer rDiscount;  
	  private Integer rTotal;     

	  private LocalDateTime rDate; // 사용일시
	
}
