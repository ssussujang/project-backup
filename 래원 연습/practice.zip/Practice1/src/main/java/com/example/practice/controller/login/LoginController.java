package com.example.practice.controller.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.practice.dao.MyService;
import com.example.practice.dto.DTO;
import com.example.practice.dto.login.LoginDTO;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/test")
public class LoginController {
	
	@Autowired
	private MyService myservice;
	
	@GetMapping("/login")
	public String loginpage() {
		return "member/welcome";
	}
	
	@PostMapping("/login")
	public String doLogin(LoginDTO loginDTO,
	                      HttpSession session,
	                      RedirectAttributes rttr) {

	    DTO user = myservice.login(loginDTO);

	    if (user == null) {
	        rttr.addFlashAttribute("msg", "이름 또는 나이가 일치하지 않습니다.");
	        return "redirect:/test/login";  
	    }

	    session.setAttribute("loginUser", user);


	    return "member/welcome";  
	}
	
	@PostMapping("/logout")
	public String logout(HttpSession session, RedirectAttributes rttr) {
	    session.invalidate();  
	    rttr.addFlashAttribute("msg", "로그아웃 되었습니다.");
	    return "redirect:/test/login";
	}
	
}
 