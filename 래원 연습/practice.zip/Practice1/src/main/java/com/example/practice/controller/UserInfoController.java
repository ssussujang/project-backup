package com.example.practice.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.practice.dao.MyService;
import com.example.practice.dto.DTO;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/test")
@RequiredArgsConstructor
public class UserInfoController {

    private final MyService myService;

    // ✅ 회원 정보 수정 화면 (로그인한 본인 기준)
    @GetMapping("/change")
    public String changePage(HttpSession session,
                             Model model,
                             RedirectAttributes rttr) {

        // 1) 세션에서 로그인 정보 가져오기
        DTO loginUser = (DTO) session.getAttribute("loginUser");

        if (loginUser == null) {
            rttr.addFlashAttribute("msg", "로그인 후 이용해주세요.");
            return "redirect:/test/login";
        }

        // 2) DB에서 내 정보 조회
        DTO user = myService.findUserById(loginUser.getU_id());

        if (user == null) {
            rttr.addFlashAttribute("msg", "회원 정보를 찾을 수 없습니다. 다시 로그인해주세요.");
            session.invalidate();
            return "redirect:/test/login";
        }

        // 3) 모델에 담아서 myidchange.html에 전달
        model.addAttribute("user", user);

        return "member/myidchange";
    }

    // ✅ 회원 정보 수정 처리
    @PostMapping("/updateUser")
    public String updateUser(DTO dto,
                             HttpSession session,
                             RedirectAttributes rttr) {

        DTO loginUser = (DTO) session.getAttribute("loginUser");

        if (loginUser == null) {
            rttr.addFlashAttribute("msg", "로그인 후 이용해주세요.");
            return "redirect:/test/login";
        }

        // 아이디는 세션 기준으로 고정 (폼에서 넘어오는 값 무시)
        dto.setU_id(loginUser.getU_id());

        // DB 업데이트
        myService.update(dto);

        // 수정된 정보 다시 조회해서 세션도 갱신
        DTO updated = myService.findUserById(loginUser.getU_id());
        session.setAttribute("loginUser", updated);

        rttr.addFlashAttribute("msg", "회원 정보가 수정되었습니다.");
        return "redirect:/test/change";
    }
}

    



