package com.example.practice.dto.receipt;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class ReceiptStatsDTO {

	// 1) daily
	private List<Map<String, Object>> dailyData;
	
	// 2) weekly
	private List<Map<String, Object>> weeklyData;
	
	// 3) Monthly
	private List <Map<String, Object>> monthlyData;
	
	// 4) 성별 
	private List <Map<String, Object>> genderData;
	
	// 5) 나의 평균 / 전체 평균
	private int myAvg;
	private int allAvg;
}
