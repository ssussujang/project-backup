package com.example.practice.controller.receipt;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.practice.ai.ReceiptAiService;
import com.example.practice.dto.DTO;          // ★ 로그인 유저 DTO

import jakarta.servlet.http.HttpSession;      // ★ 세션 주입
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/ai")
@RequiredArgsConstructor
public class ReceiptController {

    private final ReceiptAiService receiptAiService;

    // 업로드 페이지
    @GetMapping("/receipt")
    public String showReceiptForm() {
        return "ai/receipt";
    }

    @PostMapping("/receipt")
    public String analyzeReceipt(@RequestParam("file") MultipartFile file,
                                 HttpSession session,
                                 Model model) {

        // 1) 파일 체크
        if (file.isEmpty()) {
            model.addAttribute("error", "이미지 파일을 선택하세요.");
            return "ai/receipt";
        }

        // 2) 로그인 유저 확인 (세션에서 꺼내기)
        DTO loginUser = (DTO) session.getAttribute("loginUser");
        if (loginUser == null) {
            model.addAttribute("error", "로그인 후 이용 가능한 서비스입니다.");
            return "ai/receipt";
        }
        String uId = loginUser.getU_id();   // ★ 영수증에 저장할 사용자 ID

        try {
            // 3) AI 호출 + DB 저장까지 한 번에 처리
            //    -> 서비스에서 receipt_tb 에 insert 해주도록 구현
            String resultJson = receiptAiService.analyzeReceipt(file, uId);

            // 4) 화면에 JSON 출력용으로 전달
            model.addAttribute("resultJson", resultJson);

        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute(
                "error",
                "영수증 분석 중 오류가 발생했습니다: " + e.getMessage()
            );
        }

        return "ai/receipt";
    }
}
