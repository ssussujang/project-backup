(function () {
    // 컨트롤러에서 result.html을 통해 세팅한 데이터
    const data = window.receiptData || {};

    const dailyData   = data.dailyData   || [];
    const weeklyData  = data.weeklyData  || [];
    const monthlyData = data.monthlyData || [];
    const genderData  = data.genderData  || [];
    const myAvg       = data.myAvg || 0;
    const allAvg      = data.allAvg || 0;

    // 1) 일별
    const dailyLabels = dailyData.map(row => row.dt);
    const dailyTotals = dailyData.map(row => row.total);

    // 2) 주별
    const weeklyLabels = weeklyData.map(row =>
        `${row.weekStart} ~ ${row.weekEnd}`
    );
    const weeklyTotals = weeklyData.map(row => row.total);

    // 3) 월별
    const monthlyLabels = monthlyData.map(row => row.ym);
    const monthlyTotals = monthlyData.map(row => row.total);

    // 4) 성별
    const genderLabels = genderData.map(row => {
        if (row.gender === 'M') return '남';
        if (row.gender === 'F') return '여';
        return row.gender;
    });
    const genderTotals = genderData.map(row => row.total);

    function defaultOptions() {
        return {
            responsive: true,
            plugins: {
                legend: { display: true },
                tooltip: {
                    callbacks: {
                        label: function (ctx) {
                            const v = ctx.parsed.y ?? ctx.parsed;
                            return `${ctx.dataset.label}: ${v.toLocaleString()} 원`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function (v) {
                            return v.toLocaleString() + '원';
                        }
                    }
                }
            }
        };
    }

    // 일별 차트
    const dailyCtx = document.getElementById('dailyChart');
    if (dailyCtx && dailyLabels.length > 0) {
        new Chart(dailyCtx, {
            type: 'line',
            data: {
                labels: dailyLabels,
                datasets: [{
                    label: '일별 지출',
                    data: dailyTotals,
                    borderColor: '#3556ff',
                    backgroundColor: 'rgba(53, 86, 255, 0.15)',
                    tension: 0.3,
                    fill: true,
                    pointRadius: 3
                }]
            },
            options: defaultOptions()
        });
    }

    // 주별 차트
    const weeklyCtx = document.getElementById('weeklyChart');
    if (weeklyCtx && weeklyLabels.length > 0) {
        new Chart(weeklyCtx, {
            type: 'bar',
            data: {
                labels: weeklyLabels,
                datasets: [{
                    label: '주별 지출',
                    data: weeklyTotals,
                    backgroundColor: 'rgba(255, 159, 64, 0.6)'
                }]
            },
            options: defaultOptions()
        });
    }

    // 월별 차트
    const monthlyCtx = document.getElementById('monthlyChart');
    if (monthlyCtx && monthlyLabels.length > 0) {
        new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: monthlyLabels,
                datasets: [{
                    label: '월별 지출',
                    data: monthlyTotals,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)'
                }]
            },
            options: defaultOptions()
        });
    }

 // 성별 차트
const genderCtx = document.getElementById('genderChart');
if (genderCtx && genderLabels.length > 0) {

    // 성별마다 색을 직접 지정 (남=파랑, 여=핑크, 그 외=보라)
    const genderColors = genderLabels.map(label => {
        if (label === '남') {
            return 'rgba(53, 86, 255, 0.7)';      // 남 - 파랑
        } else if (label === '여') {
            return 'rgba(255, 99, 132, 0.7)';     // 여 - 핑크
        } else {
            return 'rgba(153, 102, 255, 0.7)';    // 기타
        }
    });

    new Chart(genderCtx, {
        type: 'doughnut',
        data: {
            labels: genderLabels,
            datasets: [{
                label: '성별 지출',
                data: genderTotals,
                backgroundColor: genderColors
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: function (ctx) {
                            const v = ctx.parsed;
                            return `${ctx.label}: ${v.toLocaleString()} 원`;
                        }
                    }
                }
            }
        }
    });
}



    // 평균 비교 차트
    const avgCtx = document.getElementById('avgChart');
    if (avgCtx) {
        new Chart(avgCtx, {
            type: 'bar',
            data: {
                labels: ['나의 평균', '전체 평균'],
                datasets: [{
                    label: '1회 결제 평균 금액',
                    data: [myAvg, allAvg],
                    backgroundColor: [
                        'rgba(53, 86, 255, 0.7)',
                        'rgba(201, 203, 207, 0.7)'
                    ]
                }]
            },
            options: defaultOptions()
        });
    }
})();
