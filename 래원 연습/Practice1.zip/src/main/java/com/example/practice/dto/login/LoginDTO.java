package com.example.practice.dto.login;

import lombok.Data;

@Data
public class LoginDTO {
	 private String u_id; 
	 private String u_pw;    
}
