package com.example.practice.controller.board;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.example.practice.dao.board.BoardService;
import com.example.practice.dto.DTO;          // 회원 DTO (u_id, u_name, ...)
import com.example.practice.dto.board.BoardDTO;
import com.example.practice.dto.search.Pagination;
import com.example.practice.dto.search.SearchDto;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/board")
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardservice;

    // 게시판 리스트
    @GetMapping("/mainboard")
    public String showBoardPage(@ModelAttribute("search") SearchDto searchDto, Model model) {
        List<BoardDTO> boards = boardservice.selectAllBoards(searchDto);
        int totalCount = boardservice.selectBoardCount();

        Pagination pagination = new Pagination(totalCount, searchDto);

        model.addAttribute("boards", boards);
        model.addAttribute("pagination", pagination);
        model.addAttribute("search", searchDto);

        return "board/Mainboard";
    }

    // 글쓰기 폼
    @GetMapping("/write")
    public String writeForm(Model model) {
        model.addAttribute("board", new BoardDTO());
        return "board/Write";
    }

    // 글 등록
    @PostMapping("/write")
    public String write(@ModelAttribute BoardDTO dto,
                        @SessionAttribute(value = "loginUser", required = false) DTO loginUser) {

        if (loginUser == null) {
            // 로그인 안 되어 있으면 로그인 페이지로
            return "redirect:/test/login"; // ★ 기존 LoginController가 /test/login 이라면 이렇게
        }

        // ★ b_writer에 로그인한 회원의 u_id를 저장 (아이디 기준으로 관리)
        dto.setB_writer(loginUser.getU_id());

        boardservice.insertBoard(dto);
        return "redirect:/board/mainboard";
    }

    // 글 삭제
    @PostMapping("/delete")
    public String delete(@RequestParam("b_id") int b_id,
                         @SessionAttribute(value = "loginUser", required = false) DTO loginUser) {

        if (loginUser == null) {
            return "redirect:/test/login";
        }

        // TODO: 필요하면 여기서 "작성자와 로그인 유저가 같은지" 체크 로직 추가 가능
        boardservice.deleteBoard(b_id);
        return "redirect:/board/mainboard";
    }

    // 글 수정 처리
    @PostMapping("/update")
    public String update(@ModelAttribute BoardDTO dto,
                         @SessionAttribute(value = "loginUser", required = false) DTO loginUser) {

        if (loginUser == null) {
            return "redirect:/test/login";
        }

        // TODO: 필요하면 작성자 체크 후 수정 제한 가능
        boardservice.updateBoard(dto);
        return "redirect:/board/mainboard";
    }

    // 게시글 수정 화면 (edit.html 열기)
    @GetMapping("/edit")
    public String editForm(@RequestParam("b_id") int b_id,
                           @SessionAttribute(value = "loginUser", required = false) DTO loginUser,
                           Model model) {

        if (loginUser == null) {
            return "redirect:/test/login";
        }

        // DB에서 기존 글 조회
        BoardDTO board = boardservice.selectBoardById(b_id);
        model.addAttribute("board", board);

        return "board/edit"; // templates/board/edit.html
    }
}

