package com.example.practice.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DTO {
	   private String u_id;       // 아이디
	    private String u_pw;       // 비밀번호
	    private String u_name;     // 이름
	    private String u_gender;   // 'F' or 'M'
	    private String tel1;       // 전화 앞자리 (예: 010, 02)
	    private String tel2;       // 중간
	    private String tel3;       // 끝
	    private String u_email;    
	    private LocalDateTime reg_date;
}
