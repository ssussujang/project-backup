package com.example.practice.service.receipt;

import org.springframework.stereotype.Service;

import com.example.practice.dto.receipt.ReceiptStatsDTO;
import com.example.practice.mapper.ReceiptMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReceiptResultService {

    private final ReceiptMapper receiptMapper;

    public ReceiptStatsDTO getStats(String uId) {

        ReceiptStatsDTO dto = new ReceiptStatsDTO();

        // 1) 일별
        dto.setDailyData(receiptMapper.selectDailyTotalByUser(uId));

        // 2) 주별
        dto.setWeeklyData(receiptMapper.selectWeeklyTotalByUser(uId));

        // 3) 월별
        dto.setMonthlyData(receiptMapper.selectMonthlyTotalByUser(uId));

        // 4) 성별
        dto.setGenderData(receiptMapper.selectTotalByGender());

        // 5) 평균
        dto.setMyAvg(receiptMapper.selectMyAverage(uId));
        dto.setAllAvg(receiptMapper.selectAllAverage());

        return dto;
    }
}

