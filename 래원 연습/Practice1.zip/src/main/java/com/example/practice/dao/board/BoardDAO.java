package com.example.practice.dao.board;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.practice.dto.board.BoardDTO;
import com.example.practice.dto.search.SearchDto;
import com.example.practice.mapper.BoardMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BoardDAO implements BoardService {

    private final BoardMapper boardMapper;

    @Override
    public int insertBoard(BoardDTO dto) {
        System.out.println("▶ BoardDAO.insertBoard 호출, DTO = " + dto);
        int cnt = boardMapper.insertBoard(dto);
        System.out.println("▶ MyBatis insert 결과 row 수 = " + cnt);
        return cnt;
    }


    @Override
    public BoardDTO selectBoardById(int b_id) {
        return boardMapper.selectBoardById(b_id);
    }

    @Override
    public List<BoardDTO> selectAllBoards(SearchDto searchDto) {
        return boardMapper.selectAllBoards(searchDto);
    }

    @Override
    public int updateBoard(BoardDTO dto) {
        return boardMapper.updateBoard(dto);
    }

    @Override
    public int deleteBoard(int b_id) {
        return boardMapper.deleteBoard(b_id);
    }
    
    @Override
    public int selectBoardCount() {
        return boardMapper.selectBoardCount();
    }

}

