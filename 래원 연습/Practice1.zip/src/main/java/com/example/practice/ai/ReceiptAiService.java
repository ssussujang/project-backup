package com.example.practice.ai;

import java.io.IOException;
import java.util.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@Service
public class ReceiptAiService {

	private final RestTemplate restTemplate;
	private final String apiKey;
	
	public ReceiptAiService(RestTemplate restTemplate,
							@Value("${openai.api-key}") String apiKey) {
		this.restTemplate = restTemplate;
		this.apiKey = apiKey;
	}
	
	public String analyzeReceipt(MultipartFile image) throws IOException {
		
		String base64 = Base64.getEncoder().encodeToString(image.getBytes());
		String mimeType = image.getContentType();
		if (mimeType == null) {
			mimeType = "image/png";
		}
		 String dataUrl = "data:" + mimeType + ";base64," + base64;

		 // 2) Chat Completions용 메시지 구성 (gpt-4.1-mini 사용 예시)
	        // system 메시지
	        Map<String, Object> systemMsg = new HashMap<>();
	        systemMsg.put("role", "system");
	        systemMsg.put("content",
	                "너는 영수증을 분석해서 항목별로 카테고리를 분류해 주는 어시스턴트야. " +
	                "항상 JSON 형식만 반환해. 예시는 다음과 같아:\n" +
	                "{\n" +
	                "  \"items\": [\n" +
	                "    {\"name\": \"아메리카노\", \"price\": 4500, \"category\": \"카페\"},\n" +
	                "    {\"name\": \"버스\", \"price\": 1400, \"category\": \"교통\"}\n" +
	                "  ],\n" +
	                "  \"categorySummary\": {\n" +
	                "    \"카페\": 4500,\n" +
	                "    \"교통\": 1400\n" +
	                "  },\n" +
	                "  \"total\": 5900\n" +
	                "}");
	        
	        // user 메시지: 텍스트 + 이미지
	        Map<String, Object> textPart = new HashMap<>();
	        textPart.put("type", "text");
	        textPart.put("text", "이 영수증을 보고 항목별 카테고리와 금액을 위 JSON 형태로만 출력해 줘.");

	        Map<String, Object> imageUrl = new HashMap<>();
	        imageUrl.put("url", dataUrl);

	        Map<String, Object> imagePart = new HashMap<>();
	        imagePart.put("type", "image_url");
	        imagePart.put("image_url", imageUrl);

	        List<Object> userContent = new ArrayList<>();
	        userContent.add(textPart);
	        userContent.add(imagePart);

	        Map<String, Object> userMsg = new HashMap<>();
	        userMsg.put("role", "user");
	        userMsg.put("content", userContent);

	        Map<String, Object> body = new HashMap<>();
	        body.put("model", "gpt-4.1-mini");
	        body.put("messages", List.of(systemMsg, userMsg));
	        body.put("temperature", 0);

	        // 3) HTTP 요청 헤더
	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_JSON);
	        headers.setBearerAuth(apiKey);

	        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
		
	        @SuppressWarnings("unchecked")
	        Map<String, Object> response = restTemplate.postForObject( "https://api.openai.com/v1/chat/completions",
	                entity,
	                Map.class
	        );
	        
	        if (response == null) {
	            return "OpenAI 응답이 없습니다.";
	        }
	        
	        // 5) choices[0].message.content 추출
	        @SuppressWarnings("unchecked")
	        List<Map<String, Object>> choices =
	                (List<Map<String, Object>>) response.get("choices");

	        if (choices == null || choices.isEmpty()) {
	            return "choices 가 비어 있습니다: " + response;
	        }

	        @SuppressWarnings("unchecked")
	        Map<String, Object> message =
	                (Map<String, Object>) choices.get(0).get("message");

	        Object contentObj = message.get("content");

	        // content가 String 또는 [{type:"text", text:"..."}] 인 경우 대비
	        if (contentObj instanceof String) {
	            return (String) contentObj;
	        } else if (contentObj instanceof List) {
	            StringBuilder sb = new StringBuilder();
	            for (Object partObj : (List<?>) contentObj) {
	                if (partObj instanceof Map) {
	                    Map<?, ?> partMap = (Map<?, ?>) partObj;
	                    if ("text".equals(partMap.get("type"))) {
	                        Object txt = partMap.get("text");
	                        if (txt != null) {
	                            sb.append(txt.toString());
	                        }
	                    }
	                }
	            }
	            return sb.toString();
	        } else {
	            return message.toString();
	        }
	}
}
