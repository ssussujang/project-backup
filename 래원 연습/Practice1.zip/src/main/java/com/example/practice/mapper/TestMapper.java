package com.example.practice.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.practice.dto.DTO;
import com.example.practice.dto.login.LoginDTO;

@Mapper
public interface TestMapper {

    void InsertUser(DTO dto);      // 회원가입
    void UpdateUser(DTO dto);      // 회원 수정
    int exists(String u_id);       // 아이디 중복 체크
    DTO findByIdAndPw(LoginDTO loginDTO);  // 로그인용
    void deletemember(DTO dto);   // 회원 삭제
	DTO selectUserById(String u_id);
    

}

