package com.example.practice.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.practice.dto.DTO;
import com.example.practice.dto.login.LoginDTO;
import com.example.practice.mapper.TestMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DAO implements MyService {

    @Autowired
    private final TestMapper testmapper;

    @Override
    public void register(DTO t) {
        testmapper.InsertUser(t);
    }

    @Override
    public void update(DTO t) {
        testmapper.UpdateUser(t);
    }

    @Override
    public boolean exists(String u_id) {
       
        return testmapper.exists(u_id) > 0;
    }


    @Override
    public DTO login(LoginDTO loginDTO) {

        System.out.println("로그인 시도 => id=" + loginDTO.getU_id()
                         + ", pw=" + loginDTO.getU_pw());

        DTO user = testmapper.findByIdAndPw(loginDTO);

        if (user == null) {
            System.out.println("로그인 실패 - user == null");
            return null;
        }
        return user;
    }


    @Override
    public void deletemember(DTO t) {
        testmapper.deletemember(t);
    }

    @Override
    public DTO findUserById(String u_Id) {
        return testmapper.selectUserById(u_Id);
    }

}

