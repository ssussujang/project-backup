package com.example.practice.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.practice.dto.receipt.ReceiptDTO;

@Mapper
public interface ReceiptMapper {
	 void insertReceipt(ReceiptDTO dto);
	 List<Map<String, Object>> selectDailyTotalByUser(@Param("uId") String uId);
	    List<Map<String, Object>> selectWeeklyTotalByUser(@Param("uId") String uId);
	    List<Map<String, Object>> selectMonthlyTotalByUser(@Param("uId") String uId);

	    List<Map<String, Object>> selectTotalByGender();

	    Integer selectMyAverage(@Param("uId") String uId);
	    Integer selectAllAverage();
	}
	
	
