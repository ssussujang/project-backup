package com.example.practice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.practice.dao.MyService;
import com.example.practice.dto.DTO;

@Controller
@RequestMapping("/test")
public class MainController {
	
	@Autowired
	private MyService myService;
	
	@GetMapping("/register")
	public String showRegisterForm() {
	    return "member/register";  
	}
	@PostMapping("/register")
	public String register(DTO t, RedirectAttributes ra) {
	     try {
	            myService.register(t);
	            ra.addFlashAttribute("msg", "가입이 완료되었습니다.");
	        } catch (DuplicateKeyException e) {
	            ra.addFlashAttribute("msg", "이미 존재하는 이름입니다.");
	        }
	        return "redirect:/test/login";
	}
	


}
