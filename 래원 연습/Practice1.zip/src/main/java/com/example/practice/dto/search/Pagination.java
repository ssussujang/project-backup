package com.example.practice.dto.search;

import lombok.Getter;

@Getter
public class Pagination {

    private int totalRecordCount; 
    private int totalPageCount;   

    private int startPage; 
    private int endPage;   

    private int limitStart; 
    private boolean existPrevPage;
    private boolean existNextPage;
    

    public Pagination(int totalRecordCount, SearchDto searchDto) {
        this.totalRecordCount = totalRecordCount;

        totalPageCount = ((totalRecordCount - 1) / searchDto.getRecordSize()) + 1;

        endPage = ((searchDto.getPage() - 1) / searchDto.getPageSize() + 1) * searchDto.getPageSize();
        startPage = endPage - searchDto.getPageSize() + 1;

        if (endPage > totalPageCount) {
        	
            endPage = totalPageCount;
        }

        limitStart = searchDto.getOffset();

        existPrevPage = startPage != 1;
        existNextPage = endPage < totalPageCount;
    }
	
}
