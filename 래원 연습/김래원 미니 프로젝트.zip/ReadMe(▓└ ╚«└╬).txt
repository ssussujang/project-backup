### OpenAI API 설정

이 프로젝트의 AI 기능을 사용하려면 환경변수 `OPENAI_API_KEY` 를 설정해야 합니다.

예시 (Windows CMD):

*setx OPENAI_API_KEY "sk-proj-당신의_API_키"

Git에 커밋할 때 
application.properties에
openai.api-key= {open_api_key}로 변경할 것

파일을 열고 실행할때 openai키 메모장에 적혀있는 key 값을 application.properties