package com.example.practice.dao.board;

import java.util.List;
import com.example.practice.dto.board.BoardDTO;
import com.example.practice.dto.search.SearchDto;

public interface BoardService {
    int insertBoard(BoardDTO dto);
    BoardDTO selectBoardById(int b_id);
    List<BoardDTO> selectAllBoards(SearchDto searchDto);
    int updateBoard(BoardDTO dto);
    int deleteBoard(int b_id);
    int selectBoardCount();
   
}
