function showMessage(msg) {
	
	console.log("msg from server:", msg);
    if (msg && msg.trim() !== "") {
        alert(msg);
    }
}
// 나이 숫자 검증
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("regForm");

    if (form) {
        form.addEventListener("submit", function (e) {
            let age = document.getElementById("m_age").value.trim();
            age = Number(age);

            if (isNaN(age) || age < 1 || age > 100) {
                alert("나이는 1살부터 100살까지만 숫자로 입력 가능합니다.");
                e.preventDefault();
            }
        });
    }
  
});    
    


