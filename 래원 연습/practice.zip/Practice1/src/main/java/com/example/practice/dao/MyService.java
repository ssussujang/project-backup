package com.example.practice.dao;

import com.example.practice.dto.DTO;
import com.example.practice.dto.login.LoginDTO;

public interface MyService {
    void register(DTO t);
    void update(DTO t);
    void deletemember(DTO t);
    boolean exists(String name);
    DTO login(LoginDTO loginDTO);
    DTO findUserById(String u_Id);   // ✅ 이거 사용
}
