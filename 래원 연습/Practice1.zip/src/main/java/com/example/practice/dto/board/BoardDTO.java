package com.example.practice.dto.board;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BoardDTO {
    private int b_id;
    private String b_title;
    private String b_writer;
    private String b_content;
    private LocalDateTime b_create;
    private LocalDateTime b_update;
}

